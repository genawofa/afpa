from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.

def index(request):
    return HttpResponse("Bienvenus sur le site d'Annonay Loisirs !")

def classement(request):
    return 